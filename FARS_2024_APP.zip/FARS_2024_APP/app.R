
#
# This is a Shiny web application. You can run the application by clicking
# the 'Run App' button above.
#
# Find out more about building applications with Shiny here:
#
#    https://shiny.posit.co/
#

library(shiny)
library(tidyverse)


# Import data
data_1 <- read.csv("data_1.csv")

# Prepare state-level data
state_data <- data_1 %>%
  distinct(
    STATE, STATENAME, Region, State_Population,
    Traffic_Fatalities_per_10k_Deaths,
    Pop_Death_Rate_10k,
    Accident_Rate_10k
  )

# USER INTERFACE
ui <- fluidPage(
  
  titlePanel("WHAT FACTORS EXPLAIN THE NUMBER OF DEATHS IN A SINGLE ACCIDENT EVENT (USA 2024)"),
  
  tabsetPanel(
    
    tabPanel(
      "Fatalities Distribution",
      plotOutput("plot1", height = "500px")
    ),
    
    tabPanel(
      "Lighting Conditions",
      plotOutput("plot2", height = "550px")
    ),
    
    tabPanel(
      "Rural vs Urban",
      plotOutput("plot3", height = "500px")
    ),
    
    tabPanel(
      "Weather Conditions",
      plotOutput("plot4", height = "550px")
    ),
    
    tabPanel(
      "Time of Day",
      plotOutput("plot5", height = "500px")
    ),
    
    tabPanel(
      "Death Rates by State 1",
      plotOutput("plot6", height = "650px")
    ),
    
    tabPanel(
      "Accident (Death) Rates by State 2",
      plotOutput("plot7", height = "650px")
    ),
    
    tabPanel(
      "Persons vs Fatalities",
      plotOutput("plot8", height = "550px")
    )
    
  )
)


# SERVER
server <- function(input, output, session) {
  
  # Plot 1: Distribution of fatalities
  output$plot1 <- renderPlot({
    
    ggplot(data_1, aes(x = FATALS)) +
      geom_histogram(
        binwidth = 1,
        boundary = 0.5,
        fill = "blue",
        color = "white"
      ) +
      scale_x_continuous(
        breaks = 1:max(data_1$FATALS, na.rm = TRUE)
      ) +
      labs(
        title = "Distribution of Fatalities per Crash in 2024",
        x = "Number of Fatalities",
        y = "Number of Crashes"
      ) +
      theme_minimal()
    
  })
  
  
  # Plot 2: Lighting conditions
  output$plot2 <- renderPlot({
    
    ggplot(data_1,
           aes(x = LGT_CONDNAME, y = FATALS,
               fill = LGT_CONDNAME)) +
      stat_summary(fun = sum, geom = "bar") +
      labs(
        title = "Total Fatalities by Lighting Conditions in 2024",
        x = "Lighting Conditions",
        y = "Total Fatalities"
      ) +
      theme_minimal() +
      theme(
        axis.text.x = element_text(angle = 45, hjust = 1),
        legend.position = "none"
      )
    
  })
  
  
  # Plot 3: Rural vs Urban
  output$plot3 <- renderPlot({
    
    ggplot(data_1,
           aes(x = RUR_URBNAME, y = FATALS,
               fill = RUR_URBNAME)) +
      stat_summary(fun = sum, geom = "bar") +
      scale_fill_manual(values = c(
        "Rural" = "blue",
        "Urban" = "darkorange"
      )) +
      labs(
        title = "Total Fatalities by Rural and Urban Areas in 2024",
        x = "Area Type",
        y = "Total Fatalities"
      ) +
      theme_minimal() +
      theme(
        legend.position = "none"
      )
    
  })
  
  
  # Plot 4: Weather conditions
  output$plot4 <- renderPlot({
    
    ggplot(data_1,
           aes(x = WEATHERNAME, y = FATALS,
               fill = WEATHERNAME)) +
      stat_summary(fun = sum, geom = "bar") +
      labs(
        title = "Total Fatalities by Weather Conditions in 2024",
        x = "Weather Conditions",
        y = "Total Fatalities"
      ) +
      theme_minimal() +
      theme(
        axis.text.x = element_text(angle = 45, hjust = 1),
        legend.position = "none"
      )
    
  })
  
  
  # Plot 5: Time of day
  output$plot5 <- renderPlot({
    
    ggplot(data_1,
           aes(x = time_category, y = FATALS,
               fill = time_category)) +
      stat_summary(fun = sum, geom = "bar") +
      scale_fill_manual(values = c(
        "Morning" = "gold",
        "Afternoon" = "skyblue",
        "Evening" = "orange",
        "Night" = "darkblue",
        "Unknown" = "tomato"
      )) +
      labs(
        title = "Total Fatalities by Time of Day in 2024",
        x = "Time of Day",
        y = "Total Fatalities"
      ) +
      theme_minimal() +
      theme(legend.position = "right")
    
  })
  
  
  # Plot 6: Death rates by state
  output$plot6 <- renderPlot({
    
    state_order <- state_data %>%
      arrange(Region, STATENAME) %>%
      mutate(
        x_position = row_number() +
          2 * (as.integer(factor(Region)) - 1)
      )
    
    state_plot_long <- state_order %>%
      pivot_longer(
        cols = c(
          Traffic_Fatalities_per_10k_Deaths,
          Pop_Death_Rate_10k
        ),
        names_to = "Rate_Type",
        values_to = "Rate"
      )
    
    population_labels <- state_order %>%
      mutate(
        Max_Rate = pmax(
          Traffic_Fatalities_per_10k_Deaths,
          Pop_Death_Rate_10k
        )
      )
    
    ggplot(state_plot_long,
           aes(x = x_position, y = Rate, fill = Rate_Type)) +
      geom_col(
        position = position_dodge(width = 0.8),
        width = 0.7
      ) +
      geom_text(
        data = population_labels,
        aes(
          x = x_position,
          y = Max_Rate + 7,
          label = scales::comma(State_Population)
        ),
        inherit.aes = FALSE,
        size = 2.2
      ) +
      scale_x_continuous(
        breaks = state_order$x_position,
        labels = state_order$STATENAME
      ) +
      scale_fill_manual(values = c(
        "Traffic_Fatalities_per_10k_Deaths" = "lightblue",
        "Pop_Death_Rate_10k" = "darkorange"
      )) +
      scale_y_continuous(
        expand = expansion(mult = c(0, 0.15))
      ) +
      labs(
        title = "Comparison of Death Rates by State and Region (2024)",
        subtitle = "Numbers above bars represent state populations",
        x = "States Grouped by Region",
        y = "Rate per 10,000",
        fill = "Variable"
      ) +
      theme_minimal() +
      theme(
        axis.text.x = element_text(angle = 90, hjust = 1, size = 8),
        plot.title = element_text(hjust = 0.5, face = "bold"),
        legend.position = "bottom"
      )
    
  })
  
  
  # Plot 7: Accident rates by state
  output$plot7 <- renderPlot({
    
    state_rates <- state_data %>%
      arrange(Region, STATENAME) %>%
      mutate(
        x_position = row_number() +
          2 * (as.integer(factor(Region)) - 1)
      )
    
    state_plot_long <- state_rates %>%
      pivot_longer(
        cols = c(
          Accident_Rate_10k,
          Pop_Death_Rate_10k
        ),
        names_to = "Rate_Type",
        values_to = "Rate"
      )
    
    ggplot(state_plot_long,
           aes(x = x_position, y = Rate, fill = Rate_Type)) +
      geom_col(
        position = "dodge",
        width = 0.7
      ) +
      scale_x_continuous(
        breaks = state_rates$x_position,
        labels = state_rates$STATENAME
      ) +
      scale_fill_manual(values = c(
        "Accident_Rate_10k" = "lightblue",
        "Pop_Death_Rate_10k" = "darkorange"
      )) +
      labs(
        title = "Fatal Accident Rate vs. Overall Death Rate (2024)",
        x = "States Grouped by Region",
        y = "Rate per 10,000 Population",
        fill = "Variable"
      ) +
      theme_minimal() +
      theme(
        axis.text.x = element_text(angle = 90, hjust = 1, size = 8),
        plot.title = element_text(hjust = 0.5, face = "bold"),
        legend.position = "bottom"
      )
    
  })
  
  
  # Plot 8: Persons involved vs Fatalities
  output$plot8 <- renderPlot({
    
    ggplot(data_1, aes(x = PERSONS, y = FATALS)) +
      geom_jitter(
        color = "darkblue",
        alpha = 0.35,
        width = 0.2,
        height = 0.1,
        size = 2
      ) +
      scale_x_continuous(
        breaks = scales::breaks_pretty()
      ) +
      scale_y_continuous(
        breaks = scales::breaks_pretty()
      ) +
      labs(
        title = "Persons Involved vs Fatalities in Traffic Crashes (2024)",
        subtitle = "Each point represents a traffic crash",
        x = "Number of Persons Involved",
        y = "Number of Fatalities"
      ) +
      theme_minimal() +
      theme(
        plot.title = element_text(
          hjust = 0.5,
          face = "bold"
        )
      )
    
  })
  
}

# RUN SHINY APP
shinyApp(ui = ui, server = server)